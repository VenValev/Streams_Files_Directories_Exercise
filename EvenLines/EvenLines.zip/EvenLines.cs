﻿namespace EvenLines
{
    using System;
    using System.IO;
    using System.Linq;

    public class EvenLines
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";

            ProcessLines(inputFilePath);
        }

        public static void ProcessLines(string inputFilePath)
        {
            using (StreamReader reader = new StreamReader(inputFilePath))
            {
                int count = -1;
                string line = reader.ReadLine();

                while (line != null)
                {
                    count++;
                    if (count % 2 == 0)
                    {
                        line = ReplaceLine(line);
                        line = ReverseLine(line);
                        Console.WriteLine(line);
                    }
                    
                    line = reader.ReadLine();
                }
            }
        }

        private static string ReverseLine(string line)
        {
            return string.Join(" ", line.Split().Reverse());
        }

        private static string ReplaceLine(string line)
        {
            return line.Replace("-", "@")
                .Replace(",", "@")
                .Replace(".", "@")
                .Replace("!", "@")
                .Replace("?", "@");
        }
    }
}
